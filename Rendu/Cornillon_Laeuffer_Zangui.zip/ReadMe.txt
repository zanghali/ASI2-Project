﻿// ASI2 PROJECT - READ ME

- BINOME : CORNILLON LEO - LAEUFFER LOTHAIRE - ZANGUI GHALI

- PARTIES REALISEES :

    - JEE : Toutes les parties ont été validées lors des séances de TP.
    - Node Js : Toutes les parties ont été validées lors des séances de TP.
    - React Js : Toutes les parties ont été validées lors des séances de TP.

- PARTIES NON TRAITEES :

    Nous avons eu des soucis lors de la mise en commun de nos 3 parties. La partie authentification via serveur JEE s'effectue bien
    mais pour ce qui est des communications ReactJs <-> Node Js nous n'avons pas pu finir de tout mettre en commun avant dimanche.

- COMMENTAIRES :

    - MATERIAL UI Framework utilisé pour les styles.
    - Implementation d'un webservice de génération d'UID côté serveur (Node Js).

- SCREEN CAST : https://youtu.be/T6ROJiDSTLM

- GIT : https://github.com/zanghali/ASI2-Project
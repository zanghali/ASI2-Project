package fr.cpe.common;

public enum Role {
	NONE, ADMIN
}

package fr.cpe.rest;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 * @author ubuntu
 *
 */
@ApplicationPath("/rest")
public class ApplicationRestInit extends Application {

}
